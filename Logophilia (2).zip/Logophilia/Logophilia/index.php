<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logophilia</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="navbar-brand">Logophilia.</div>
            <ul class="navbar-menu">
                <li><a href="#home">Home</a></li>
                <li><a href="#word-of-the-day">Word of the Day</a></li>
                <li><a href="#dictionary">Dictionary</a></li>
                <li><a href="#quotes">Quotes</a></li>
                <li><a href="#apis">APIs</a></li>
            </ul>
        </nav>
    </header>

    <!-- Parallax Introduction -->
    <div class="parallax" id="home">
        <div class="parallax-content">
            <div class="home">Logophilia.</div>
            <p>Discover a love for words like never before. Expand your vocabulary, find meanings, and explore the beauty of languages!</p>
        </div>
    </div>

    <main>

        <!-- Word of the Day Section -->
        <section id="word-of-the-day" class="word-of-the-day-section">
                <div class="word-of-the-day-container">
                    <div class="wtitle">Word of the Day</div>
                    
                    <?php
                        // Your Wordnik API key
                        $apiKey = "fehfvni4xyfpro72x6ziazrmm6l3rggsvm3otmyglxly9t7wm";
                        $apiUrl = "https://api.wordnik.com/v4/words.json/wordOfTheDay?api_key=$apiKey";

                        // Fetch data from the API
                        $response = file_get_contents($apiUrl);

                        if ($response) {
                            $data = json_decode($response, true);
                            $word = $data['word'] ?? 'N/A';
                            $definition = $data['definitions'][0]['text'] ?? 'No definition available.';
                            echo "<div class='word-of-the-day-card'>";
                            echo "<h2 class='word-title'>$word</h2>";
                            echo "<p class='word-definition'>$definition</p>";
                            echo "</div>";
                        } else {
                            echo "<p class='error-message'>Unable to fetch the Word of the Day. Please try again later.</p>";
                        }
                    ?>

                    <a href="#dictionary" class="btn-explore">Want to know more? Explore the Dictionary!</a>
                </div>
        </section>


        <!-- Dictionary Section -->
        <section id="dictionary" class="dictionary-section">
            <div class="dictionary-container">
                <div class="wtitle">Dictionary</div>
                <p class="dictionary-description">Discover the synonyms and meanings of any word. Just enter a word below and explore!</p>
                
                <!-- Search Form -->
                <form id="dictionaryForm" method="POST" class="search-form">
                    <input type="text" id="word" name="word" placeholder="Enter a word..." required>
                    <button type="submit" name="search_synonyms" class="search-button">Search</button>
                </form>

                <!-- Results Display -->
                <div class="results" id="results">
                    <!-- Results will be displayed here dynamically -->
                </div>
            </div>
        </section>



        <!-- Quotes Section -->
        <section id="quotes">
            <div class="wtitle">Trivia Quotes</div>
            <p>Select a category to get a quote:</p>
            
            <!-- Category dropdown -->
            <div class="select-container">
                <select id="categorySelect">
                    <option value="">Select Category</option>
                    <option value="age">Age</option>
                    <option value="alone">Alone</option>
                    <option value="amazing">Amazing</option>
                    <option value="anger">Anger</option>
                    <option value="architecture">Architecture</option>
                    <option value="art">Art</option>
                    <option value="attitude">Attitude</option>
                    <option value="beauty">Beauty</option>
                    <option value="best">Best</option>
                    <option value="birthday">Birthday</option>
                    <option value="business">Business</option>
                    <option value="car">Car</option>
                    <option value="change">Change</option>
                    <option value="communication">Communication</option>
                    <option value="computers">Computers</option>
                    <option value="cool">Cool</option>
                    <option value="courage">Courage</option>
                    <option value="dad">Dad</option>
                    <option value="dating">Dating</option>
                    <option value="death">Death</option>
                    <option value="design">Design</option>
                    <option value="dreams">Dreams</option>
                    <option value="education">Education</option>
                    <option value="environmental">Environmental</option>
                    <option value="equality">Equality</option>
                    <option value="experience">Experience</option>
                    <option value="failure">Failure</option>
                    <option value="faith">Faith</option>
                    <option value="family">Family</option>
                    <option value="famous">Famous</option>
                    <option value="fear">Fear</option>
                    <option value="fitness">Fitness</option>
                    <option value="food">Food</option>
                    <option value="forgiveness">Forgiveness</option>
                    <option value="freedom">Freedom</option>
                    <option value="friendship">Friendship</option>
                    <option value="funny">Funny</option>
                    <option value="future">Future</option>
                    <option value="god">God</option>
                    <option value="good">Good</option>
                    <option value="government">Government</option>
                    <option value="graduation">Graduation</option>
                    <option value="great">Great</option>
                    <option value="happiness">Happiness</option>
                    <option value="health">Health</option>
                    <option value="history">History</option>
                    <option value="home">Home</option>
                    <option value="hope">Hope</option>
                    <option value="humor">Humor</option>
                    <option value="imagination">Imagination</option>
                    <option value="inspirational">Inspirational</option>
                    <option value="intelligence">Intelligence</option>
                    <option value="jealousy">Jealousy</option>
                    <option value="knowledge">Knowledge</option>
                    <option value="leadership">Leadership</option>
                    <option value="learning">Learning</option>
                    <option value="legal">Legal</option>
                    <option value="life">Life</option>
                    <option value="love">Love</option>
                    <option value="marriage">Marriage</option>
                    <option value="medical">Medical</option>
                    <option value="men">Men</option>
                    <option value="mom">Mom</option>
                    <option value="money">Money</option>
                    <option value="morning">Morning</option>
                    <option value="movies">Movies</option>
                    <option value="success">Success</option>
                </select>
            </div>
            
            <button onclick="getQuotes()">Get Quotes</button>

            <!-- Display quotes here -->
            <div id="quotesDisplay" class="quotes-display"></div>
        </section>

        <section id="apis">
    
            <div class="api-container">
                <!-- API 1 -->
                <div class="api-card">
                    <img src="pic/wordnik.png" alt="API 1">
                    <h2>Word of the Day API</h2>
                    <p>This API provides a daily word along with its definition, which can be displayed on the website. It helps users learn a new word each day. You can get the API key from Wordnik.</p>
                </div>

                <!-- API 2 -->
                <div class="api-card">
                    <img src="pic/stands4api.png" alt="API 2">
                    <h2>Dictionary API</h2>
                    <p>This API allows you to fetch definitions and synonyms of words. It's an essential tool for the dictionary feature on your site. You can obtain the API key from Stands4.</p>
                </div>

                <!-- API 3 -->
                <div class="api-card">
                    <img src="pic/ninjaapi.png" alt="API 3">
                    <h2>Quotes API</h2>
                    <p>This API provides quoattion services, allowing users to generate quotes based on categories.</p>
                </div>
            </div>
        </section>

        <!-- Footer Section -->
        <footer>
            <div class="footer-content">
                <p>&#169; 2024 Made by Watermelon League</p>
            </div>
        </footer>


    </main>

    <script>
        // Function to fetch quotes based on selected category
        function getQuotes() {
            const category = document.getElementById('categorySelect').value;
            const apiUrl = category 
                ? `https://api.api-ninjas.com/v1/quotes?category=${category}` 
                : 'https://api.api-ninjas.com/v1/quotes';  // No category will return quotes from all categories

            fetch(apiUrl, {
                method: 'GET',
                headers: {
                    'X-Api-Key': 'ApsPr8BAeOjfVspLwZOTOg==lW4B22QL2UjVyEdO'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.length > 0) {
                    displayQuotes(data);
                } else {
                    showError('No quotes available. Please try again later.');
                }
            })
            .catch(error => {
                console.error('Error loading quotes:', error);
                showError('Error loading quotes. Please try again later.');
            });
        }

        // Function to display quotes
        function displayQuotes(quotes) {
            let quotesHtml = '';
            quotes.forEach(quote => {
                quotesHtml += `
                    <div class="quote">
                        <p>"${quote.quote}"</p>
                        <p>- ${quote.author}</p>
                        <p><strong>Category:</strong> ${quote.category}</p>
                    </div>
                `;
            });
            document.getElementById('quotesDisplay').innerHTML = quotesHtml;
        }

        // Function to display error message
        function showError(message) {
            document.getElementById('quotesDisplay').innerHTML = `<p>${message}</p>`;
        }
    </script>

    <script>
            document.getElementById('dictionaryForm').addEventListener('submit', function (event) {
            event.preventDefault();  // Prevent the default form submission behavior

            const word = document.getElementById('word').value;
            const resultsContainer = document.getElementById('results');

            // Clear previous results
            resultsContainer.innerHTML = '';

            const apiUrl = `https://www.stands4.com/services/v2/syno.php?uid=12912&tokenid=m9VymTE9bG9JOM1O&word=${encodeURIComponent(word)}&format=xml`;

            // Fetch synonyms from the API
            fetch(apiUrl)
                .then(response => response.text())
                .then(data => {
                    const parser = new DOMParser();
                    const xml = parser.parseFromString(data, 'text/xml');
                    const results = xml.getElementsByTagName('result');

                    if (results.length > 0) {
                        let resultHTML = `<h3>Synonyms for '${word}':</h3>`;
                        Array.from(results).forEach(result => {
                            const term = result.getElementsByTagName('term')[0].textContent;
                            const definition = result.getElementsByTagName('definition')[0].textContent;
                            const synonyms = result.getElementsByTagName('synonyms')[0]?.textContent || 'No synonyms available';

                            resultHTML += `
                                <div class="result-item">
                                    <strong>Term:</strong> ${term}<br>
                                    <strong>Definition:</strong> ${definition}<br>
                                    <strong>Synonyms:</strong> ${synonyms}<br>
                                </div>
                            `;
                        });
                        resultsContainer.innerHTML = resultHTML;
                    } else {
                        resultsContainer.innerHTML = `<p class="error-message">No synonyms found for '${word}'.</p>`;
                    }
                })
                .catch(() => {
                    resultsContainer.innerHTML = `<p class="error-message">Error retrieving synonyms. Please try again later.</p>`;
                });
        });

    </script>

</body>
</html>
